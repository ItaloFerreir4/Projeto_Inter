using barbeariaGabriel.Models;
using Microsoft.AspNetCore.Mvc;
using barbeariaGabriel.Repositories;

namespace barbeariaGabriel.Controllers
{
    public class AgendamentoController : Controller
    {
        private IAgendamentoRepository AgendamentoRepository;

        private IServicoRepository ServicoRepository;

        private IBarbeiroRepository BarbeiroRepository;

        public AgendamentoController(IAgendamentoRepository AgendamentoRepository, IServicoRepository ServicoRepository, IBarbeiroRepository BarbeiroRepository)
        {
            this.AgendamentoRepository = AgendamentoRepository;
            this.ServicoRepository = ServicoRepository;
            this.BarbeiroRepository = BarbeiroRepository;
        }

        public ActionResult Index()
        {
            List<Agendamento> agendamentos = AgendamentoRepository.Read();
            //Console.WriteLine("oi");
            return View(agendamentos);
            
        }

        [HttpGet]
        public ActionResult SelectBarbeiro()
        {
            ViewBag.Barbeiro = BarbeiroRepository.Read();
            return View();
        }

        [HttpPost]
        public ActionResult SelectDate(Agendamento agendamento)
        {
            List<int> Horarios = new List<int>{6,7,8,9,10,11,13,14,15,16,17,18};

            var HorariosBarbeiros = AgendamentoRepository.ReadDate(agendamento);

            foreach(var Hora in HorariosBarbeiros)
            {
                var x = Hora.Horario;
                Horarios.Remove(x.Hour);
                
            }
            ViewBag.HorariosDisponiveis = Horarios;
            
            ViewBag.Servico = ServicoRepository.Read();
            return View(agendamento);
        }

        [HttpPost]
        public ActionResult CreateAgendamento(Agendamento agendamento)
        {
            agendamento.Horario = agendamento.Horario.Date.AddHours(agendamento.Hora);
            AgendamentoRepository.Create(agendamento);
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            AgendamentoRepository.Delete(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Update(int id)
        {
            var agendamento = AgendamentoRepository.Read(id);
            
            List<int> Horarios = new List<int>{6,7,8,9,10,11,13,14,15,16,17,18};

            var HorariosBarbeir = AgendamentoRepository.ReadDate(agendamento);

            foreach(var Hora in HorariosBarbeir)
            {
                var x = Hora.Horario;
                Horarios.Remove(x.Hour);
                
            }
            ViewBag.HorariosDisponiveis = Horarios;

            
            return View(agendamento);
        }

        [HttpPost]
        public ActionResult Update(int id, Agendamento agendamento)
        {
            agendamento.Horario = agendamento.Horario.Date.AddHours(agendamento.Hora);
            
            AgendamentoRepository.Update(id, agendamento);
            return RedirectToAction("Index");
        }

    }

}