using Microsoft.AspNetCore.Mvc;
using barbeariaGabriel.Models;
using barbeariaGabriel.Repositories;

namespace barbeariaGabriel.Controllers
{
    public class BarbeiroController : Controller
    {
        private IBarbeiroRepository barbeiroRepository;
        private IUsuarioRepository usuarioRepository;

        public BarbeiroController(IBarbeiroRepository barbeiroRepository, IUsuarioRepository usuarioRepository)
        {
            this.barbeiroRepository = barbeiroRepository;
            this.usuarioRepository = usuarioRepository;
        }

        public ActionResult Index()
        {
            List<Barbeiro> barbeiros = barbeiroRepository.Read();
            //Console.WriteLine(barbeiros);
            return View(barbeiros);
        }

        [HttpGet]
        public ActionResult Create()
        {
            ViewBag.Usuario = usuarioRepository.Read();
            return View();
        }

        [HttpPost]
        public ActionResult Create(Barbeiro barbeiro)
        {
            barbeiroRepository.Create(barbeiro);
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            barbeiroRepository.Delete(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Update(int id)
        {
            var barbeiro = barbeiroRepository.Read(id);
            return View(barbeiro);
        }

        [HttpPost]
        public ActionResult Update(int id, Barbeiro barbeiro)
        {   
            barbeiroRepository.Update(id,barbeiro);
            return RedirectToAction("Index");
        }
    }
}