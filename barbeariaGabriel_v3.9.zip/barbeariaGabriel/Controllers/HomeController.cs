using barbeariaGabriel.Models;
using Microsoft.AspNetCore.Mvc;
using barbeariaGabriel.Repositories;

namespace barbeariaGabriel.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return RedirectToAction("Login", "Login");
        }
    }
}