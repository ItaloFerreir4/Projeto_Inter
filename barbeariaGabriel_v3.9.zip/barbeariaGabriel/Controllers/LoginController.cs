using barbeariaGabriel.Models;
using Microsoft.AspNetCore.Mvc;
using barbeariaGabriel.Repositories;

namespace barbeariaGabriel.Controllers
{
    public class LoginController : Controller
    {
        private IBarbeiroRepository BarbeiroRepository;
        private ILoginRepository LoginRepository;

        private IUsuarioRepository UsuarioRepository;

        public LoginController(ILoginRepository LoginRepository, IUsuarioRepository UsuarioRepository, IBarbeiroRepository BarbeiroRepository)
        {
            this.LoginRepository = LoginRepository;
            this.UsuarioRepository = UsuarioRepository;
            this.BarbeiroRepository = BarbeiroRepository;
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Teste()
        {
            return View();
        }

         public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(Login login)
        {
            // if(ModelState.IsValid) {}

            var logon = LoginRepository.Read(login);

            if(logon == null)
            {
                ViewBag.Message = "Erro login";
                return View();
            }
            else if(logon.Administrador == 1 )
            {
                HttpContext.Session.SetInt32("Id", logon.IdUsuario);
                HttpContext.Session.SetString("Nome", logon.Nome);
                HttpContext.Session.SetString("Cpf", logon.Cpf);
                HttpContext.Session.SetString("Email", logon.Email);
                HttpContext.Session.SetString("Numero", logon.Numero);
                HttpContext.Session.SetString("Login", logon.LoginUsuario);
                HttpContext.Session.SetString("Senha", logon.SenhaUsuario);
                HttpContext.Session.SetInt32("Administrador", logon.Administrador);

                Console.WriteLine("Administrador");
                return RedirectToAction("Index", "Usuario");
            }
            else if(login.LoginUsuario == logon.LoginUsuario && login.SenhaUsuario == logon.SenhaUsuario)
            {
                HttpContext.Session.SetInt32("Id", logon.IdUsuario);
                HttpContext.Session.SetString("Nome", logon.Nome);
                HttpContext.Session.SetString("Cpf", logon.Cpf);
                HttpContext.Session.SetString("Email", logon.Email);
                HttpContext.Session.SetString("Numero", logon.Numero);
                HttpContext.Session.SetString("Login", logon.LoginUsuario);
                HttpContext.Session.SetString("Senha", logon.SenhaUsuario);


                string CPF = logon.Cpf;

                var barbeiro = BarbeiroRepository.ReadBarbeiro(CPF);

                if(barbeiro.IdBarbeiro >= 1){
                    HttpContext.Session.SetInt32("Barbeiro", 1);
                }else{
                    HttpContext.Session.SetInt32("Barbeiro", 0);
                }

                Console.WriteLine("Usuario");
                return RedirectToAction("Index", "Usuario");
            }            

            return RedirectToAction("Index", "Usuario");
            
        }

        public ActionResult Logout()
        {

            HttpContext.Session.Clear();
            return RedirectToAction("Login","Login");
            
        }
    }
}