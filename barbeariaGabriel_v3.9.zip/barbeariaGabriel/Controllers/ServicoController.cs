using barbeariaGabriel.Models;
using Microsoft.AspNetCore.Mvc;
using barbeariaGabriel.Repositories;

namespace barbeariaGabriel.Controllers
{
    public class ServicoController : Controller
    {
        private IServicoRepository ServicoRepository;

        public ServicoController(IServicoRepository ServicoRepository)
        {
            this.ServicoRepository = ServicoRepository;
        }

        public ActionResult Index()
        {
            List<Servico> servicos = ServicoRepository.Read();

            return View(servicos);

        }
    

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Servico servico)
        {
            ServicoRepository.Create(servico);
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            ServicoRepository.Delete(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Update(int id)
        {
            var servico = ServicoRepository.Read(id);
            return View(servico);
        }

        [HttpPost]
        public ActionResult Update(int id, Servico servico)
        {
            // Console.WriteLine(id);
            // Console.WriteLine(servico);
            ServicoRepository.Update(id, servico);
            return RedirectToAction("Index");
        } 
    }
}