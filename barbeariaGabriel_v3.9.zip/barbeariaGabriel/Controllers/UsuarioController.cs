using barbeariaGabriel.Models;
using Microsoft.AspNetCore.Mvc;
using barbeariaGabriel.Repositories;

namespace barbeariaGabriel.Controllers
{
    public class UsuarioController : Controller
    {
        private IUsuarioRepository repository;
        private IServicoRepository servicoRepository;
        private ILoginRepository loginRepository;

        public UsuarioController(IUsuarioRepository repository, IServicoRepository servicoRepository, ILoginRepository loginRepository)
        {
            this.repository = repository;
            this.servicoRepository = servicoRepository;
            this.loginRepository = loginRepository;
        }

        public ActionResult Index()
        {

            int? id = HttpContext.Session.GetInt32("Id") as int?;
            if(id == null)
            {
                return RedirectToAction("Login", "Login");
            }
            
            List<Usuario> usuarios = repository.Read();

            //Console.WriteLine(usuarios);

            return View(usuarios);

        }

        // public ActionResult Filter(int id)
        // {
        //     ViewBag.Servico = servicoRepository.Read();
        //     //List<Usuario> usuarios = repository.ReadByServicos(id);
        //     return View("Index");
        // }      

        [HttpGet]
        public ActionResult Create()
        {
            ViewBag.Servico = servicoRepository.Read();
            return View();
        }

        [HttpPost]
        public ActionResult Create(Usuario usuario)
        {
            var cadastro = repository.Create(usuario);
            
            HttpContext.Session.SetInt32("Cadastro", cadastro);
            
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            repository.Delete(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Update(int id)
        {
            var usuario = repository.Read(id);
            Console.WriteLine("usuario.Cpf");
            return View(usuario);
        }

        [HttpPost]
        public ActionResult Update(int id, Usuario usuario)
        {
            repository.Update(id, usuario);
            return RedirectToAction("Index");
        } 

        
    }
}