namespace barbeariaGabriel.Models
{
    public class Agendamento
    {
        public int IdAgendamento { get; set; }
        public DateTime Horario { get; set; }
        public int IdServico { get; set; }
        public string CpfCliente { get; set; }
        public string CpfBarbeiro { get; set; }
        public string Servico { get; set; }
        public string NomeUsuario { get; set; }
        public string NomeBarbeiro { get; set; }
        public int Hora { get; set; }
        public int Administrator { get; set; }
    }
}