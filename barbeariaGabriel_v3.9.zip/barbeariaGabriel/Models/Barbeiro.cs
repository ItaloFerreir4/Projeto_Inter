namespace barbeariaGabriel.Models
{
    public class Barbeiro : Usuario
    {
        public string Cpf { get; set; }
        public int IdBarbeiro { get; set; }
        public decimal Salario { get; set; }
        public string NomeBarbeiro { get; set; }
    }
}