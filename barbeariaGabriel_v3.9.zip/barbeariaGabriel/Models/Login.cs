using System.ComponentModel.DataAnnotations;

namespace barbeariaGabriel.Models
{
    public class Login : Usuario
    {
        public string LoginUsuario { get; set; }
        public string SenhaUsuario { get; set; }
        public int UserBarbeiro { get; set; }
        public int Administrador { get; set; }
    }
}