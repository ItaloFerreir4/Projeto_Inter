namespace barbeariaGabriel.Models
{
    public class Servico
    {
        public int IdServico { get; set; }
        public string NomeServico { get; set; }
        public decimal Valor { get; set; }
    }
}