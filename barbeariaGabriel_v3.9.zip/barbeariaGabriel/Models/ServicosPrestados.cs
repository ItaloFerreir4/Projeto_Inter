namespace barbeariaGabriel.Models
{
    public class ServicosPrestados
    {
        public int IdServico { get; set; }
        public string Cpf { get; set; }
    }
}