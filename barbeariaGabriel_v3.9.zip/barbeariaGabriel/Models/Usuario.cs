namespace barbeariaGabriel.Models
{
    public class Usuario
    {
        // propriedades
        public int IdUsuario { get; set; }
        public string LoginUsuario { get; set; }
        public string SenhaUsuario { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Numero { get; set; }
        public string Cpf { get; set; }
        public int eBarbeiro { get; set; }
        public int Administrador { get; set; }
    }
}