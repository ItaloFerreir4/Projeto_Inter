using barbeariaGabriel.Repositories;

namespace barbeariaGabriel
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddControllersWithViews();
            builder.Services.AddSession();

            builder.Services.AddTransient<IUsuarioRepository, UsuarioSqlRepository>();
            builder.Services.AddTransient<IServicoRepository, ServicoSqlRepository>();
            builder.Services.AddTransient<IAgendamentoRepository, AgendamentoSqlRepository>();
            builder.Services.AddTransient<IBarbeiroRepository, BarbeiroSqlRepository>();
            builder.Services.AddTransient<ILoginRepository, LoginSqlRepository>();

            var app = builder.Build();
            app.UseSession();
            app.UseStaticFiles();
            app.MapDefaultControllerRoute();
            app.Run();
        }
    }
}


