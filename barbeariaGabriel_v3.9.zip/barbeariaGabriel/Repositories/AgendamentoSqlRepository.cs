using System.Data.SqlClient;
using barbeariaGabriel.Models;

namespace barbeariaGabriel.Repositories
{
    public class AgendamentoSqlRepository : DBContext, IAgendamentoRepository
    {
        public List<Agendamento> ReadDate(Agendamento agendamento)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"SELECT * FROM Agendamentos 
                WHERE CpfBarbeiro = @CpfBarbeiro 
                AND CAST(Horario AS DATE) = CAST(@Dia AS DATE)";

                cmd.Parameters.AddWithValue("@CpfBarbeiro", agendamento.CpfBarbeiro);
                cmd.Parameters.AddWithValue("@Dia", agendamento.Horario);

                Console.WriteLine(agendamento.Horario);

                SqlDataReader reader = cmd.ExecuteReader();

                List<Agendamento> lista = new List<Agendamento>();

                while(reader.Read())
                {
                    Console.WriteLine("entra krlh");
                    lista.Add(
                        new Agendamento{
                            Horario = (DateTime)reader["Horario"],
                            CpfBarbeiro = (string)reader["CpfBarbeiro"]
                        }
                    );
                }
                return lista;
            }
            catch(Exception ex) 
            {
                Console.WriteLine(ex.Message);
                return null;
            }
            finally
            {
                Dispose();
            }
        }
        public void Create(Agendamento agendamento)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"INSERT INTO Agendamentos     
                    VALUES (@Horario,@IdServico,@CpfCliente,@CpfBarbeiro)";

                cmd.Parameters.AddWithValue("@Horario", agendamento.Horario);
                cmd.Parameters.AddWithValue("@IdServico", agendamento.IdServico);
                cmd.Parameters.AddWithValue("@CpfCliente", agendamento.CpfCliente);
                cmd.Parameters.AddWithValue("@CpfBarbeiro", agendamento.CpfBarbeiro);

                cmd.ExecuteNonQuery();

                Console.WriteLine(agendamento.Horario);
                Console.WriteLine(agendamento.IdServico);
                Console.WriteLine(agendamento.CpfCliente);
                Console.WriteLine(agendamento.CpfBarbeiro);
                Console.WriteLine("foi");
                // Console.WriteLine("foi");
            }
            catch(Exception ex) 
            {
                // Console.WriteLine("erro");
                // Console.WriteLine(agendamento.Horario);
                // Console.WriteLine(agendamento.IdServico);
                // Console.WriteLine(agendamento.CpfCliente);
                Console.WriteLine("erro");
                // Logar os erros (Sentry, App Insights, etc)...
            }
            finally
            {
                Dispose();
            }
        }

        public void Delete(int id)
        {
            try{
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"DELETE FROM Agendamentos WHERE IdAgendamento = @id";

                cmd.Parameters.AddWithValue("@id", id);

                cmd.ExecuteNonQuery();
            }
            catch(Exception ex) 
            {
                // Logar os erros (Sentry, App Insights, etc)...
            }
            finally
            {
                Dispose();
            }
        }

        public List<Agendamento> Read()
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"SELECT * FROM vAgendamento order by IdAgendamento";

                SqlDataReader reader = cmd.ExecuteReader();

                List<Agendamento> lista = new List<Agendamento>();

                while(reader.Read())
                {
                    lista.Add(
                        new Agendamento{
                            IdAgendamento = (int)reader["IdAgendamento"],
                            Horario = (DateTime)reader["Horario"],
                            IdServico = (int)reader["IdServico"],
                            CpfCliente = (string)reader["CpfCliente"],
                            Servico = (string)reader["Servico"],
                            NomeUsuario = (string)reader["NomeUsuario"],
                            NomeBarbeiro = (string)reader["NomeBarbeiro"]
                        }
                    );
                }
                return lista;
            }
            catch(Exception ex) 
            {
                // Logar os erros (Sentry, App Insights, etc)...
                return null;
            }
            finally
            {
                Dispose();
            }
        }     

        public Agendamento Read(int id)
        {
            SqlCommand cmd = new SqlCommand();
            try
            {
                
                
                cmd.Connection = connection;
                cmd.CommandText = @"SELECT * FROM Agendamentos WHERE IdAgendamento = @id";

                cmd.Parameters.AddWithValue("@id", id);

                SqlDataReader reader = cmd.ExecuteReader();            
                Agendamento a = null;
                if(reader.Read())
                {
                    a = new Agendamento{
                        IdAgendamento = (int)reader["IdAgendamento"],
                        Horario = (DateTime)reader["Horario"],
                        CpfBarbeiro = (string)reader["CpfBarbeiro"]
                    };
                }
                
                Console.WriteLine("sei la");

                reader.Close();

                return a;
            }
            catch(Exception ex) 
            {
                // Logar os erros (Sentry, App Insights, etc)...
                Console.WriteLine("manga");
                return null;
            }
            finally
            {
                
                //Dispose();
            }            
        }

        public void Update(int id, Agendamento agendamento)
        {
            try
            {
                // Console.WriteLine(servico.NomeServico);
                // Console.WriteLine(servico.Valor);
                // Console.WriteLine(servico.IdServico);

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"UPDATE Agendamentos
                    SET Horario = @Horario
                    WHERE IdAgendamento = @id";

                cmd.Parameters.AddWithValue("@Horario", agendamento.Horario);
                cmd.Parameters.AddWithValue("@id", id);
                cmd.ExecuteNonQuery();
            }
            catch(Exception ex) 
            {
                Console.WriteLine(ex.Message);
                // Logar os erros (Sentry, App Insights, etc)...
            }
            finally
            {
                Dispose();
            }
        }
    }
}