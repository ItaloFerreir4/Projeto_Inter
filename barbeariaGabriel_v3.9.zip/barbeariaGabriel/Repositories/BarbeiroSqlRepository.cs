using System.Data.SqlClient;
using barbeariaGabriel.Models;

namespace barbeariaGabriel.Repositories
{
    public class BarbeiroSqlRepository : DBContext, IBarbeiroRepository
    {
        public void Create(Barbeiro barbeiro)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.CommandText = @"sp_add_barbeiro";

                cmd.Parameters.AddWithValue("@Cpf", barbeiro.Cpf);
                cmd.Parameters.AddWithValue("@LoginUsuario", barbeiro.LoginUsuario);
                cmd.Parameters.AddWithValue("@SenhaUsuario", barbeiro.SenhaUsuario);
                cmd.Parameters.AddWithValue("@Nome", barbeiro.Nome);
                cmd.Parameters.AddWithValue("@Email", barbeiro.Email);
                cmd.Parameters.AddWithValue("@Numero", barbeiro.Numero);
                cmd.Parameters.AddWithValue("@Administrador", barbeiro.Administrador);
                cmd.Parameters.AddWithValue("@Salario", barbeiro.Salario);


                cmd.ExecuteNonQuery();
            }
            catch(Exception ex) 
            {
                //Console.WriteLine("Barbeiro ja cadastrado");
            }
            finally
            {
                Dispose();
            }
        }

        public void Delete(int id)
    {
        try{
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;
            cmd.CommandText = @"DELETE FROM Barbeiros WHERE IdBarbeiro = @Id";

            cmd.Parameters.AddWithValue("@Id", id);

            cmd.ExecuteNonQuery();
        }
        catch(Exception ex) 
        {
        }
        finally
        {
            Dispose();
        }
    }

    public List<Barbeiro> Read()
    {
        try{
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;
            cmd.CommandText = @"SELECT * FROM vBarbeiro order by IdBarbeiro";

            SqlDataReader reader = cmd.ExecuteReader();

            List<Barbeiro> lista = new List<Barbeiro>();

            while(reader.Read())
            {
                lista.Add(
                    new Barbeiro{
                        Cpf = (string)reader["Cpf"],
                        IdBarbeiro = (int)reader["IdBarbeiro"],
                        Salario = (decimal)reader["Salario"],
                        NomeBarbeiro = (string)reader["NomeBarbeiro"]
                    }
                );
            }
            //Console.WriteLine("foi");
            return lista;
        }
        catch(Exception ex) 
        {
            //Console.WriteLine("erro");
            // Logar os erros (Sentry, App Insights, etc)...
            return null;
        }
        finally
        {
            Dispose();
        }
    }

    public Barbeiro Read(int id)
    {
        try{
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;
            cmd.CommandText = @"SELECT * FROM vBarbeiro WHERE IdBarbeiro = @Id";

            cmd.Parameters.AddWithValue("@Id", id);

            SqlDataReader reader = cmd.ExecuteReader();

            if(reader.Read())
            {
                return new Barbeiro {
                    Cpf = (string)reader["Cpf"],
                    IdBarbeiro = (int)reader["IdBarbeiro"],
                    Salario = (decimal)reader["Salario"],
                    NomeBarbeiro = (string)reader["NomeBarbeiro"]
                };
            }

            return null;
        }
        catch(Exception ex) 
        {
            // Logar os erros (Sentry, App Insights, etc)...
            return null;
        }
        finally
        {
            Dispose();
        }
    }

    public Barbeiro ReadBarbeiro(string Cpf)
    {
        try{
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;
            cmd.CommandText = @"SELECT * FROM Barbeiros WHERE Cpf = @Cpf";

            cmd.Parameters.AddWithValue("@Cpf", Cpf);

            SqlDataReader reader = cmd.ExecuteReader();

            if(reader.Read())
            {
                Console.WriteLine("é barbeiro");
                return new Barbeiro {
                    Cpf = (string)reader["Cpf"],
                    IdBarbeiro = (int)reader["IdBarbeiro"],
                    Salario = (decimal)reader["Salario"]
                };
            }

            return new Barbeiro {
                Cpf = " ",
                IdBarbeiro = 0,
                Salario = 0
            };
        }
        catch(Exception ex) 
        {
            Console.WriteLine("Erro SQL");
            // Logar os erros (Sentry, App Insights, etc)...
            return null;
        }
        finally
        {
            Dispose();
        }
    }

    public void Update(int id, Barbeiro barbeiro)
    {
        try{
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = connection;
            cmd.CommandText = @"UPDATE Barbeiros SET Salario = @Salario WHERE IdBarbeiro = @Id";

            cmd.Parameters.AddWithValue("@Id", barbeiro.IdBarbeiro);
            cmd.Parameters.AddWithValue("@Salario", barbeiro.Salario);

            SqlDataReader reader = cmd.ExecuteReader();
        }
        catch(Exception ex) 
        {

        }
        finally
        {
            Dispose();
        }
    }
    }
}