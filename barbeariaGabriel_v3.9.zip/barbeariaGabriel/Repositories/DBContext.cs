using System.Data.SqlClient;

namespace barbeariaGabriel.Repositories
{
    public abstract class DBContext
    {
        private readonly string strConn = @"Data Source=localhost\sqlexpress;
        Initial Catalog=Barbearia;
        Integrated Security=True;";
         // User Id=sa; Password=F4tecSQL!

         protected SqlConnection connection;

         public DBContext()
         {
             connection = new SqlConnection(strConn);
             connection.Open();
         }

         public void Dispose()
         {
             connection.Close();
         }
    }
}