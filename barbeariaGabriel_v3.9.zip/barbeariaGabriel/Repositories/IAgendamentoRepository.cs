using barbeariaGabriel.Models;

namespace barbeariaGabriel.Repositories
{
    public interface IAgendamentoRepository
    {
        void Create(Agendamento agendamento);
        List<Agendamento> Read();
        Agendamento Read(int id);
        void Update(int id, Agendamento agendamento);
        void Delete(int id);
        List<Agendamento> ReadDate(Agendamento agendamento);
    }
}