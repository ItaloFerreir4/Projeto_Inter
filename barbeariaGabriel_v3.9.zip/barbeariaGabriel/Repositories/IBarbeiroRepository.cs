using barbeariaGabriel.Models;

namespace barbeariaGabriel.Repositories
{
    public interface IBarbeiroRepository
    {
        void Create(Barbeiro barbeiro);
        List<Barbeiro> Read();
        Barbeiro Read(int id);
        Barbeiro ReadBarbeiro(string Cpf);
        void Update(int id, Barbeiro barbeiro);
        void Delete(int id);
    }
}