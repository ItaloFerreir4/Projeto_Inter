using barbeariaGabriel.Models;

namespace barbeariaGabriel.Repositories
{
    public interface ILoginRepository
    {
        Login Read(Login login);
    }
}