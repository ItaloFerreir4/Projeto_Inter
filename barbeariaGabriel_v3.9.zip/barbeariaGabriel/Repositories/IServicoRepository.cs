using barbeariaGabriel.Models;

namespace barbeariaGabriel.Repositories
{
    public interface IServicoRepository
    {
        void Create(Servico servico);
        List<Servico> Read();
        Servico Read(int id);
        void Update(int id, Servico servico);
        void Delete(int id);
    }
}