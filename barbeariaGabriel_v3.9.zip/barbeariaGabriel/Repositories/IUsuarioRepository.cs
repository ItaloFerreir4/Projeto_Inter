using barbeariaGabriel.Models;

namespace barbeariaGabriel.Repositories
{
    public interface IUsuarioRepository
    {
        int Create(Usuario usuario);
        List<Usuario> Read();
        List<Usuario> ReadByServicos(int id);
        Usuario Read(int id);
        void Update(int id, Usuario usuario);
        void Delete(int id);
    }
}