using System.Data.SqlClient;
using barbeariaGabriel.Models;

namespace barbeariaGabriel.Repositories
{
    public class LoginSqlRepository : DBContext, ILoginRepository
    {
        public Login Read(Login login)
        {
            try
            {                
                
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"SELECT * FROM Usuarios WHERE LoginUsuario = @Login and SenhaUsuario = @Senha";

                cmd.Parameters.AddWithValue("@Login", login.LoginUsuario);
                cmd.Parameters.AddWithValue("@Senha", login.SenhaUsuario);

                SqlDataReader reader = cmd.ExecuteReader();
                
                if(reader.Read())
                {
                    return new Login {
                        IdUsuario = (int)reader["IdUsuario"],
                        LoginUsuario = (string)reader["LoginUsuario"],
                        SenhaUsuario = (string)reader["SenhaUsuario"],
                        Nome = (string)reader["Nome"],
                        Email = (string)reader["Email"],
                        Numero = (string)reader["Numero"],
                        Cpf = (string)reader["Cpf"],
                        Administrador = (int)reader["Administrador"]
                    };                    
                }
                 

                return null;
            }
            catch(Exception ex) 
            {
                // Logar os erros (Sentry, App Insights, etc)...
                return null;
            }
            finally
            {
                Dispose();
            }            
        }
    }
}