using System.Data.SqlClient;
using barbeariaGabriel.Models;

namespace barbeariaGabriel.Repositories
{
    public class ServicoSqlRepository : DBContext, IServicoRepository
    {
        public void Create(Servico servico)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"INSERT INTO Servicos     
                    VALUES (@nomeServico, @valor)";

                cmd.Parameters.AddWithValue("@nomeServico", servico.NomeServico);
                cmd.Parameters.AddWithValue("@valor", servico.Valor);

                cmd.ExecuteNonQuery();
            }
            catch(Exception ex) 
            {
                // Logar os erros (Sentry, App Insights, etc)...
            }
            finally
            {
                Dispose();
            }
        }

        public void Delete(int id)
        {
            try{
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"DELETE FROM Servicos WHERE IdServico = @id";

                cmd.Parameters.AddWithValue("@id", id);

                cmd.ExecuteNonQuery();
            }
            catch(Exception ex) 
            {
                // Logar os erros (Sentry, App Insights, etc)...
            }
            finally
            {
                Dispose();
            }
        }

        public List<Servico> Read()
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"SELECT * FROM Servicos order by IdServico";

                SqlDataReader reader = cmd.ExecuteReader();

                List<Servico> lista = new List<Servico>();

                while(reader.Read())
                {
                    lista.Add(
                        new Servico{
                            IdServico = (int)reader["IdServico"],
                            NomeServico = (string)reader["NomeServico"],
                            Valor = (decimal)reader["Valor"],
                        }
                    );
                }
                //Console.WriteLine(lista);
                return lista;
            }
            catch(Exception ex) 
            {
                // Logar os erros (Sentry, App Insights, etc)...
                return null;
            }
            finally
            {
                Dispose();
            }
        }     

        public Servico Read(int id)
        {
            try
            {
                
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"SELECT * FROM Servicos WHERE IdServico = @id";

                cmd.Parameters.AddWithValue("@id", id);

                SqlDataReader reader = cmd.ExecuteReader();
                
                if(reader.Read())
                {
                    return new Servico {
                        IdServico = (int)reader["IdServico"],
                        NomeServico = (string)reader["NomeServico"],
                        Valor = (decimal)reader["Valor"]
                    };
                }
                 

                return null;
            }
            catch(Exception ex) 
            {
                // Logar os erros (Sentry, App Insights, etc)...
                return null;
            }
            finally
            {
                Dispose();
            }            
        }

        public void Update(int id, Servico servico)
        {
            try
            {
                // Console.WriteLine(servico.NomeServico);
                // Console.WriteLine(servico.Valor);
                // Console.WriteLine(servico.IdServico);

                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"UPDATE Servicos
                    SET NomeServico = @NomeServico, Valor = @Valor
                    WHERE IdServico = @id";

                cmd.Parameters.AddWithValue("@NomeServico", servico.NomeServico);
                cmd.Parameters.AddWithValue("@Valor", servico.Valor);
                cmd.Parameters.AddWithValue("@id", servico.IdServico);

                cmd.ExecuteNonQuery();
            }
            catch(Exception ex) 
            {
                Console.WriteLine(ex.Message);
                // Logar os erros (Sentry, App Insights, etc)...
            }
            finally
            {
                Dispose();
            }
        }
    }
}