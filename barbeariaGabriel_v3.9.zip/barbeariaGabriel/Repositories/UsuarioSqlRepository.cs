using System.Data.SqlClient;
using barbeariaGabriel.Models;

namespace barbeariaGabriel.Repositories
{
    public class UsuarioSqlRepository : DBContext, IUsuarioRepository
    {
        public int Create(Usuario usuario)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"INSERT INTO Usuarios 
                    VALUES (@cpf, @login, @senha, @nome, @email, @numero, @admin)";

                cmd.Parameters.AddWithValue("@cpf", usuario.Cpf);
                cmd.Parameters.AddWithValue("@login", usuario.LoginUsuario);
                cmd.Parameters.AddWithValue("@senha", usuario.SenhaUsuario);
                cmd.Parameters.AddWithValue("@nome", usuario.Nome);
                cmd.Parameters.AddWithValue("@email", usuario.Email);
                cmd.Parameters.AddWithValue("@numero", usuario.Numero);
                cmd.Parameters.AddWithValue("@admin", 0);

                cmd.ExecuteNonQuery();

                return 1;

            }
            catch(Exception ex) 
            {
                // Logar os erros (Sentry, App Insights, etc)...
                return 0;
            }
            finally
            {
                Dispose();
            }
        }


        public void Delete(int id)
        {
            try{
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"DELETE FROM Usuarios WHERE IdUsuario = @id";

                cmd.Parameters.AddWithValue("@id", id);

                cmd.ExecuteNonQuery();
            }
            catch(Exception ex) 
            {
                // Logar os erros (Sentry, App Insights, etc)...
            }
            finally
            {
                Dispose();
            }
        }

        public List<Usuario> Read()
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"SELECT * FROM Usuarios order by IdUsuario";

                SqlDataReader reader = cmd.ExecuteReader();

                List<Usuario> lista = new List<Usuario>();

                while(reader.Read())
                {
                    lista.Add(
                        new Usuario {
                            IdUsuario = (int)reader["IdUsuario"],
                            Cpf = (string)reader["Cpf"],
                            LoginUsuario = (string)reader["LoginUsuario"],
                            SenhaUsuario = (string)reader["SenhaUsuario"],
                            Nome = (string)reader["Nome"],
                            Email = (string)reader["Email"],
                            Numero = (string)reader["Numero"],
                            Administrador = (int)reader["Administrador"]
                        }
                    );
                }

                return lista;
            }
            catch(Exception ex) 
            {
                // Logar os erros (Sentry, App Insights, etc)...
                return null;
            }
            finally
            {
                Dispose();
            }
        }

        public List<Usuario> ReadByServicos(int id)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"SELECT * FROM Usuarios WHERE IdUsuario = @id";

                cmd.Parameters.AddWithValue("@id", id);

                SqlDataReader reader = cmd.ExecuteReader();

                List<Usuario> lista = new List<Usuario>();

                while(reader.Read())
                {
                    lista.Add(
                        new Usuario {
                            Cpf = (string)reader["Cpf"],
                            IdUsuario = (int)reader["IdProduto"],
                            LoginUsuario = (string)reader["Login"],
                            SenhaUsuario = (string)reader["Senha"],
                            Nome = (string)reader["Nome"],
                            Email = (string)reader["Email"],
                            Numero = (string)reader["Numero"]
                        }
                    );
                }

                return lista;
            }
            catch(Exception ex) 
            {
                // Logar os erros (Sentry, App Insights, etc)...
                return null;
            }
            finally
            {
                Dispose();
            }
        }        

        public Usuario Read(int id)
        {
            try
            {
                
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"SELECT * FROM Usuarios WHERE IdUsuario = @id";

                cmd.Parameters.AddWithValue("@id", id);

                SqlDataReader reader = cmd.ExecuteReader();
                
                if(reader.Read())
                {
                    // Console.WriteLine((int)reader["IdUsuario"]);
                    // Console.WriteLine((string)reader["LoginUsuario"]);
                    // Console.WriteLine((string)reader["SenhaUsuario"]);
                    // Console.WriteLine((string)reader["Nome"]);
                    // Console.WriteLine((string)reader["Email"]);
                    // Console.WriteLine((string)reader["Numero"]);
                    // Console.WriteLine((string)reader["Cpf"]);
                    return new Usuario {
                        IdUsuario = (int)reader["IdUsuario"],
                        LoginUsuario = (string)reader["LoginUsuario"],
                        SenhaUsuario = (string)reader["SenhaUsuario"],
                        Nome = (string)reader["Nome"],
                        Email = (string)reader["Email"],
                        Numero = (string)reader["Numero"],
                        Cpf = (string)reader["Cpf"]
                    };
                }
                 

                return null;
            }
            catch(Exception ex) 
            {
                // Logar os erros (Sentry, App Insights, etc)...
                return null;
            }
            finally
            {
                Dispose();
            }            
        }

        public void Update(int id, Usuario usuario)
        {
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = connection;
                cmd.CommandText = @"UPDATE Usuarios
                    SET Cpf = @cpf, LoginUsuario = @login, SenhaUsuario = @senha, Nome = @nome, Email = @email, Numero = @numero
                    WHERE IdUsuario = @id";

                cmd.Parameters.AddWithValue("@cpf", usuario.Cpf);
                cmd.Parameters.AddWithValue("@login", usuario.LoginUsuario);
                cmd.Parameters.AddWithValue("@senha", usuario.SenhaUsuario);
                cmd.Parameters.AddWithValue("@nome", usuario.Nome);
                cmd.Parameters.AddWithValue("@email", usuario.Email);
                cmd.Parameters.AddWithValue("@numero", usuario.Numero);
                cmd.Parameters.AddWithValue("@id", id);

                cmd.ExecuteNonQuery();
            }
            catch(Exception ex) 
            {
                Console.WriteLine(ex.Message);
                // Logar os erros (Sentry, App Insights, etc)...
            }
            finally
            {
                Dispose();
            }
        }
    }
}