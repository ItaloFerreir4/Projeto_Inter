CREATE DATABASE BDEcommerce
GO

USE BDEcommerce
GO

CREATE TABLE Produto
(
    IdProduto    int                primary key        identity,
    Nome        varchar(200)    not null,
    Descricao    varchar(max)    not null,
    Preco        decimal(9,2)    not null,
    Desconto    decimal(4,2)    not null
)

INSERT INTO Produto VALUES ('Lápis', 'Azul', 2.50, 1.20)

SELECT * FROM Produto

CREATE TABLE Categoria
(
	IdCategoria		int				primary key		identity,
	Nome			varchar(200)	not null
)

ALTER TABLE Produto ADD IdCategoria int -- references Categoria(IdCategoria)

ALTER TABLE Produto add foreign key (IdCategoria) references Categoria(IdCategoria)

INSERT INTO Categoria VALUES ('Papelaria')

INSERT INTO Categoria VALUES ('Informática')

select * from Categoria

UPDATE Produto Set IdCategoria = 1

SELECT Produto.*, Categoria.Nome as Categoria FROM Produto, Categoria WHERE Produto.IdCategoria = Categoria.IdCategoria

CREATE VIEW vProduto
as
SELECT Produto.*, Categoria.Nome as Categoria FROM Produto JOIN Categoria ON Produto.IdCategoria = Categoria.IdCategoria

select * from vProduto


---------------------------------------INTER DISCIPLINAR-------------------------------------------------


CREATE DATABASE Barbearia
go

USE Barbearia
go

DROP DATABASE Barbearia

--------------------------- DROP TABLES ------------------------------------------------------

DROP TABLE Usuarios
DROP TABLE Barbeiros
DROP TABLE Servicos
DROP TABLE Agendamentos
DROP TABLE Login

--------------------------- CREATE TABLES ------------------------------------------------------

CREATE TABLE Usuarios
(
    Cpf	   varchar(12) not null primary key,
	IdUsuario int not null identity,
	LoginUsuario		varchar(200) not null UNIQUE,
	SenhaUsuario		varchar(200) not null,
    Nome        varchar(200)    not null,
    Email    varchar(200)    not null,
    Numero        varchar(12)    not null, 
	Administrador int
)

CREATE TABLE Barbeiros
(
	Cpf   varchar(12) not null primary key,
	IdBarbeiro int not null identity,
	Salario      decimal(9,2)    not null,
	foreign key (Cpf) references Usuarios (Cpf) on delete cascade ,
)

CREATE TABLE Servicos
(
    IdServico    int                primary key        identity,
	NomeServico		varchar(200) not null,
	Valor		decimal(9,2) not null,
)

CREATE TABLE Login
(
	LoginUsuario		varchar(200) not null,
	SenhaUsuario		varchar(200) not null,
	foreign key (LoginUsuario) references Usuarios (LoginUsuario) on delete cascade ,
)

CREATE TABLE Agendamentos
(
	IdAgendamento	int      primary key        identity,
	Horario		datetime	not null,
	IdServico		int not null,
	CpfCliente		varchar(12) not null,
	CpfBarbeiro		varchar(12) not null,
	foreign key (IdServico) references Servicos (IdServico),
	foreign key (CpfCliente) references Usuarios (Cpf),
	foreign key (CpfBarbeiro) references Barbeiros (Cpf)
)


--------------------------- SELECTS ------------------------------------------------------
--------------------------- USUARIOS ------------------------------
SELECT * FROM Usuarios order by IdUsuario

SELECT * FROM Usuarios WHERE LoginUsuario = 'loginLeo' and SenhaUsuario = 'senhaLeo'

INSERT INTO Usuarios VALUES (45371455687,'admin','admin','Administrador','admin@gmail.com','17988343324',1)
INSERT INTO Usuarios VALUES (11233455678,'loginAna','senhaAna','Ana','Ana@gmail.com',17966452338)
--------------------------- HORARIOS ------------------------------
SELECT * FROM Agendamentos

SELECT * FROM Agendamentos WHERE CAST(Horario AS DATE) = '2022-03-20'

INSERT INTO Agendamentos VALUES ('2022-20-03 13:00',1,45375455687,43121599801 ) -- INSERÇÃO DE DATE TIME (AAAA-DD-MM HH:MM:SS:MSMS)
--------------------------- BARBEIROS ------------------------------
SELECT * FROM Barbeiros
INSERT INTO Barbeiros VALUES (43121599801, 350)
Delete barbeiros where IdBarbeiro = 2
--------------------------- SERVICOS ------------------------------
SELECT * FROM Servicos
INSERT INTO Servicos VALUES	('Corte de Cabelo', 30.00)




--------------------------- VIEWS -----------------------------------------------
--------------------------- SELECT PAGINA AGENDAMENTO ---------------

CREATE VIEW vAgendamento as SELECT Agendamentos.*, Servicos.NomeServico as Servico, Usuarios.Nome as NomeUsuario, (SELECT Usuarios.Nome FROM Usuarios WHERE Usuarios.Cpf = Barbeiros.Cpf) as NomeBarbeiro FROM Agendamentos 
JOIN Servicos ON Agendamentos.IdServico = Servicos.IdServico 
JOIN Usuarios ON Agendamentos.CpfCliente = Usuarios.Cpf 
JOIN Barbeiros ON Agendamentos.CpfBarbeiro = Barbeiros.Cpf
SELECT * FROM vAgendamento

--------------------------- SELECT PAGINA BARBEIRO ---------------

CREATE VIEW vBarbeiro as SELECT Barbeiros.*, Usuarios.Nome as NomeBarbeiro FROM Barbeiros JOIN Usuarios ON Barbeiros.Cpf = Usuarios.Cpf
SELECT * FROM vBarbeiro


-------------------------- STORED PROCEDURES --------------------------------------

CREATE PROCEDURE sp_add_barbeiro @Cpf varchar(200), @LoginUsuario varchar (200), @SenhaUsuario varchar(200), @Nome varchar(200), @Email varchar (200), @Numero varchar(200), @Salario decimal(9,2)
as 
	INSERT INTO Usuarios VALUES (@Cpf,@LoginUsuario,@SenhaUsuario,@Nome,@Email,@Numero)
	INSERT INTO Barbeiros VALUES (@Cpf, @Salario)


-- CREATE PROCEDURE NOME_PROCEDURE PARAM1 TIPO, PARAM2 TIPO
-- AS
-- CODIGO DE INSERÇÃO DA TABELA PRIMARIA
-- CODIGO DE INSERÇÃO DA TABELA QUE TA A FOREIGN KEY
-- OS PARAMETROS UTILIZA OS @PARAM QUE CRIOU NA PROCEDURE

